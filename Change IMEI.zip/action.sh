#!/bin/sh

echo ""
sleep 1s
echo -ne '                     □□□□□□□□□□0% '
sleep 0.1
echo -ne '                     ■■■■■■■■■■100% '
sleep 0.1

    echo ""
    echo "😔"
    echo "😭"
    echo "💔"
    
    sleep 1

    
    
IMEI=86916$(tr -dc '1-9' < /dev/urandom | head -c 10)

while echo "$IMEI" | grep -q "'"
do
    echo ""
    echo "- - - - - - - - - -"
    echo "https://t.me/+1spFdLMoEmczMWQ1 My Groups"
    echo "- - - - - - - - - -"
    echo ""
done 

echo "$IMEI
>/data/adb/modules/ALING_IMEI/IMEI/LoveXin
chmod 777 /data/adb/modules/ALING_IMEI/IMEI/IMEI.sh
sleep 1
/data/adb/modules/Love_Xin/IMEI/IMEI.sh


am start -a android.intent.action.VIEW -d tg://resolve?domain=LoveXin >/dev/null 2>&1