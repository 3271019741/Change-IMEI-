#!/sbin/sh
#####################
SKIPUNZIP=1

unzip -j -o "${ZIPFILE}" 'IMEI/*' -d $MODPATH/IMEI >&2
unzip -j -o "${ZIPFILE}" 'service.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'action.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'uninstall.sh' -d $MODPATH >&2
unzip -j -o "${ZIPFILE}" 'module.prop' -d $MODPATH >&2

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0777
set_perm $MODPATH/action.sh 0 0 0777
set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/IMEI/IMEI.sh 0 0 0777

IMEI=86916$(tr -dc '1-9' < /dev/urandom | head -c 10)
while echo "$IMEI" | grep -q "'"
do
    echo ""
    echo "- - - - - - - - - -"
    echo "https://t.me/+1spFdLMoEmczMWQ1My Groups"
    echo "- - - - - - - - - -"
    echo ""
done 

echo "$IMEI
>$MODPATH/IMEI/LoveXin
am start -a android.intent.action.VIEW -d tg://resolve?domain=LoveXin >/dev/null 2>&1