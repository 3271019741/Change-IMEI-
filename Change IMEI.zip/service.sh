#!/system/bin/sh

MODDIR=${0%/*}

(
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
  sleep 5
done
sleep 30
chmod 777 /data/adb/modules/ALING_IMEI/IMEI/IMEI.sh
sleep 1
/data/adb/modules/ALING_IMEI/IMEI/IMEI.sh
)&